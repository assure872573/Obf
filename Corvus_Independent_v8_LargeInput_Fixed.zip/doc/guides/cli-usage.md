# CLI Usage

## Entry points

- packaged CLI: `prometheus-lua`
- source CLI: `lua ./cli.lua`

Both call the same CLI implementation (`src/cli.lua`).

## Basic usage

```bash
prometheus-lua --preset Medium ./input.lua
```

## Output file behavior

If `--out` is not provided:

- `input.lua` -> `input.obfuscated.lua`
- `input` -> `input.obfuscated.lua`

## Common workflows

Use the built-in preset:

```bash
prometheus-lua --preset Medium ./src/main.lua
```

Use a custom config file:

```bash
prometheus-lua --config ./prometheus.config.lua ./src/main.lua
```

Force Lua target:

```bash
prometheus-lua --preset Medium --LuaU ./src/main.lua
```

Enable pretty output:

```bash
prometheus-lua --preset Medium --pretty ./src/main.lua
```

## Notes

- Unknown `--...` options are ignored with a warning.
- If no config/preset is passed, Corvus falls back to `Medium`.
- `update` command uses the official installer script from GitHub.
