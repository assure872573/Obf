# Presets

Corvus exposes one built-in preset in `src/presets.lua`:

- `Medium`

Use it with:

```bash
prometheus-lua --preset Medium ./file.lua
```

## Medium

The Medium pipeline uses one VM compilation pass and the following stages:

1. `EncryptStrings`
2. `ConstantArray`
3. `Vmify`
4. `NumbersToExpressions`
5. `WrapInFunction`

The output string alphabet is based on the ConstantArray codec and includes `/`, `[`, `]`, digits, and the `|` symbol in its randomized alphabet.

Generated output is reparsed before it is returned so malformed code is detected during generation rather than later at runtime.
