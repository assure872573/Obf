# Quickstart: First Obfuscation

You can quickly try Corvus in the web playground. For large scripts, use the CLI workflow below.

Create a simple Lua file:

```lua
print("Hello, World")
```

Run Corvus from the repository root:

```bash
lua ./cli.lua --preset Medium ./hello.lua
```

Corvus will write:

- `hello.obfuscated.lua` (default output path)

Run the result with your target Lua/Luau runtime to validate behavior.

## Default behavior

- `Medium` is the only built-in preset.
- If no preset/config is passed, the CLI uses `Medium`.
- The pipeline performs string encryption, constant-array encoding, one VM compilation pass, number-expression transformation, and function wrapping.
