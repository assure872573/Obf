# Corvus Engine

Corvus is now organized around a Corvus-native transformation pipeline.

The original parser/AST infrastructure is retained as a compatibility foundation for Lua/Luau syntax handling. The exposed obfuscation engine no longer uses the old Prometheus Medium step chain. The Medium preset is composed of Corvus-native stages:

- Corvus Literal Morph
- Corvus Expression Morph
- Corvus Structure Morph
- Corvus name generator
- Corvus pipeline and validation

The project deliberately avoids the experimental VM/dispatcher/radix changes from the earlier v2/v3 builds. Correctness is prioritized over adding transformations that cannot be validated reliably.

No obfuscator can make client-executed code impossible to inspect. The goal here is to remove recognizable legacy output patterns and make automated pattern-based recovery substantially less dependent on a known Prometheus layout.
