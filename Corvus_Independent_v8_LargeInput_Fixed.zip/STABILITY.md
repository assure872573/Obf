# Corvus Stable Luau

Stable build focused on correctness and Luau compatibility.

## Medium preset

- LuaVersion: LuaU
- EncryptStrings
- ConstantArray
- Vmify
- NumbersToExpressions
- WrapInFunction
- Generated-output syntax validation enabled

## Compatibility fixes

- Luau compound assignments such as `+=`, `-=`, `*=`, `/=`, `%=`, `^=` and `..=` are parsed when LuaU is selected.
- `continue` is supported by the LuaU parser.
- ConstantArray dynamic string prefixes support the extended character set, including `_`, `-`, `*`, `:`, `+`, `%`, `;`, `\\`, brackets and braces.
- Dynamic prefixes are escaped before being embedded into generated string literals.

This build does not include the experimental affine VM/block-ID changes or the experimental radix-86 string encoding. Those changes were intentionally excluded in favor of stability.

Validation performed on the bundled test suite: all 16 tests completed successfully through the Corvus pipeline.
