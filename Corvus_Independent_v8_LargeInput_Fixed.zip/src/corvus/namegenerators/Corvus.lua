local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
local tail = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"

local function encode(n)
    local first = (#chars)
    local out = "c"
    n = math.floor(n or 0)
    local x = n % first
    out = out .. chars:sub(x + 1, x + 1)
    n = math.floor(n / first)
    while n > 0 do
        local y = n % #tail
        out = out .. tail:sub(y + 1, y + 1)
        n = math.floor(n / #tail)
    end
    return out
end

local state = 0
local function prepare()
    state = math.random(0, 2147483646)
end

local function generateName(id)
    return encode(id + state)
end

return {
    prepare = prepare,
    generateName = generateName,
}
