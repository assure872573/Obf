local Step = require("corvus.frontend.step")
local Ast = require("corvus.frontend.ast")
local visitast = require("corvus.frontend.visitast")
local AstKind = Ast.AstKind

local LiteralMorph = Step:extend()
LiteralMorph.Name = "Corvus Literal Morph"
LiteralMorph.Description = "Corvus-native literal representation layer"
LiteralMorph.SettingsDescriptor = {
    StringThreshold = {type = "number", default = 1, min = 0, max = 1},
    NumberThreshold = {type = "number", default = 0.85, min = 0, max = 1},
}

local function globalCall(scope, baseName, methodName, args)
    local baseScope, baseId = scope:resolveGlobal(baseName)
    local base = Ast.VariableExpression(baseScope, baseId)
    local index = Ast.IndexExpression(base, Ast.StringExpression(methodName))
    return Ast.FunctionCallExpression(index, args)
end

local function number(v)
    return Ast.NumberExpression(v)
end

local function canUseGlobalString(scope)
    -- If the source declares/assigns a global named `string`, using
    -- string.char in generated code could call the user value instead of
    -- the standard library. In that case keep literals as literals.
    local globalScope = scope
    while globalScope and not globalScope.isGlobal do
        globalScope = globalScope.parentScope
    end
    if not globalScope then
        return true
    end
    return not globalScope:hasVariable("string")
end

local function encodedString(scope, value)
    if value == "" then
        return Ast.StringExpression("")
    end
    -- For large literals, let the VM hide the final source instead of creating
    -- tens of thousands of AST nodes. The VM encodes the complete post-transform
    -- source compactly, so this path is both faster and safer for large inputs.
    if #value > 2048 then
        return Ast.StringExpression(value)
    end

    -- Split medium literals into bounded runtime-decoded chunks.
    local chunkSize = 128
    local parts = {}
    local pos = 1
    while pos <= #value do
        local last = math.min(pos + chunkSize - 1, #value)
        local key = math.random(19, 233)
        local args = {}
        for i = pos, last do
            local b = value:byte(i)
            local enc = (b + key) % 256
            local a = Ast.SubExpression(number(enc), number(key), false)
            a = Ast.ModExpression(a, number(256), false)
            table.insert(args, a)
        end
        parts[#parts + 1] = globalCall(scope, "string", "char", args)
        pos = last + 1
    end

    local result = parts[1]
    for i = 2, #parts do
        result = Ast.StrCatExpression(result, parts[i], false)
    end
    return result
end

local function mixedNumber(v)
    -- Only rewrite exact, finite integers in the IEEE-754 exact-integer range.
    -- This avoids changing floating-point rounding, signed zero, NaN, or infinities.
    if type(v) ~= "number" or v ~= v or v == math.huge or v == -math.huge then
        return Ast.NumberExpression(v)
    end

    if v == 0 or v % 1 ~= 0 or math.abs(v) > 900719925474000 then
        return Ast.NumberExpression(v)
    end

    if math.random() > 0.85 then
        return Ast.NumberExpression(v)
    end

    local b = math.random(-1000, 1000)
    if v + b > 900719925474000 or v + b < -900719925474000 then
        return Ast.NumberExpression(v)
    end

    return Ast.SubExpression(number(v + b), number(b), false)
end

function LiteralMorph:init() end
function LiteralMorph:apply(ast)
    visitast(ast, nil, function(node)
        if node.kind == AstKind.StringExpression and math.random() <= self.StringThreshold then
            local scope = node.scope or ast.globalScope
            -- Avoid runtime dependency on a user-defined global `string`.
            if canUseGlobalString(scope) then
                return encodedString(scope, node.value)
            end
        end
        if node.kind == AstKind.NumberExpression and math.random() <= self.NumberThreshold then
            return mixedNumber(node.value)
        end
    end)
    return ast
end

return LiteralMorph
