local Step = require("corvus.frontend.step")
local Ast = require("corvus.frontend.ast")
local visitast = require("corvus.frontend.visitast")
local AstKind = Ast.AstKind

local StructureMorph = Step:extend()
StructureMorph.Name = "Corvus Structure Morph"
StructureMorph.Description = "Corvus-native structural normalization"
StructureMorph.SettingsDescriptor = {
    Threshold = {type = "number", default = 0.65, min = 0, max = 1},
}

function StructureMorph:init() end
function StructureMorph:apply(ast)
    visitast(ast, nil, function(node, data)
        if node.kind == AstKind.IfStatement and math.random() <= self.Threshold then
            -- Preserve semantics while forcing a fresh condition node.
            if node.condition and node.condition.isConstant then
                node.condition = Ast.AndExpression(Ast.BooleanExpression(true), node.condition, false)
            end
        elseif node.kind == AstKind.ReturnStatement and math.random() <= self.Threshold then
            for i, expr in ipairs(node.args) do
                if expr and expr.kind == AstKind.BooleanExpression then
                    node.args[i] = Ast.OrExpression(expr, Ast.BooleanExpression(false), false)
                end
            end
        end
    end)
    return ast
end

return StructureMorph
