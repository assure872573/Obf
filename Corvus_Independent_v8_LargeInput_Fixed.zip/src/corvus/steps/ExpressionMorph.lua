local Step = require("corvus.frontend.step")
local Ast = require("corvus.frontend.ast")
local visitast = require("corvus.frontend.visitast")
local AstKind = Ast.AstKind

local ExpressionMorph = Step:extend()
ExpressionMorph.Name = "Corvus Expression Morph"
ExpressionMorph.Description = "Corvus-native expression reshaping"
ExpressionMorph.SettingsDescriptor = {
    Threshold = {type = "number", default = 0.55, min = 0, max = 1},
    Enabled = {type = "boolean", default = false},
}

local function n(v) return Ast.NumberExpression(v) end

function ExpressionMorph:init() end
function ExpressionMorph:apply(ast)
    -- Arithmetic identities can alter floating-point edge cases (for example -0).
    -- Keep this step disabled unless explicitly enabled by a custom configuration.
    if self.Enabled ~= true then
        return ast
    end
    visitast(ast, nil, function(node)
        if math.random() > self.Threshold then return end
        if node.kind == AstKind.AddExpression and node.rhs and node.rhs.isConstant and type(node.rhs.value) == "number" then
            local k = math.random(2, 17)
            node.lhs = Ast.AddExpression(node.lhs, Ast.SubExpression(n(k), n(k), false), false)
            return node
        elseif node.kind == AstKind.SubExpression and node.rhs and node.rhs.isConstant and type(node.rhs.value) == "number" then
            local k = math.random(2, 17)
            node.lhs = Ast.AddExpression(node.lhs, Ast.SubExpression(n(k), n(k), false), false)
            return node
        elseif node.kind == AstKind.MulExpression and node.rhs and node.rhs.isConstant and type(node.rhs.value) == "number" and node.rhs.value ~= 0 then
            local k = math.random(2, 9)
            node.lhs = Ast.MulExpression(node.lhs, Ast.DivExpression(n(k), n(k), false), false)
            return node
        end
    end)
    return ast
end

return ExpressionMorph
