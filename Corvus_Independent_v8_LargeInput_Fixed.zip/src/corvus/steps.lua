return {
    LiteralMorph = require("corvus.steps.LiteralMorph"),
    ExpressionMorph = require("corvus.steps.ExpressionMorph"),
    StructureMorph = require("corvus.steps.StructureMorph"),
}
