local Enums = require("corvus.frontend.enums")
local Parser = require("corvus.frontend.parser")
local Unparser = require("corvus.frontend.unparser")
local logger = require("logger")
local CorvusSteps = require("corvus.steps")
local CorvusNames = require("corvus.namegenerators.Corvus")

local Pipeline = {}
Pipeline.__index = Pipeline

function Pipeline:new(settings)
    settings = settings or {}
    local luaVersion = settings.LuaVersion or "LuaU"
    assert(Enums.Conventions[luaVersion], "Corvus does not support the requested Lua version")
    local obj = {
        LuaVersion = luaVersion,
        PrettyPrint = settings.PrettyPrint == true,
        VarNamePrefix = settings.VarNamePrefix or "",
        Seed = settings.Seed or 0,
        ValidateOutput = settings.ValidateOutput ~= false,
        parser = Parser:new({LuaVersion = luaVersion}),
        unparser = Unparser:new({LuaVersion = luaVersion, PrettyPrint = settings.PrettyPrint == true}),
        steps = {},
        namegenerator = CorvusNames,
        conventions = Enums.Conventions[luaVersion],
        UseVM = settings.UseVM == true,
        VMCount = math.max(1, math.min(5, math.floor(tonumber(settings.VMCount) or 1))),
    }
    setmetatable(obj, self)
    return obj
end

function Pipeline:fromConfig(config)
    config = config or {}
    local p = Pipeline:new(config)
    p:setNameGenerator(CorvusNames)
    for _, spec in ipairs(config.Steps or {}) do
        local ctor = CorvusSteps[spec.Name]
        assert(ctor, "Unknown Corvus step: " .. tostring(spec.Name))
        p:addStep(ctor:new(spec.Settings or {}))
    end
    return p
end

function Pipeline:addStep(step) table.insert(self.steps, step) end
function Pipeline:getSteps() return self.steps end
function Pipeline:resetSteps() self.steps = {} end
function Pipeline:setNameGenerator(generator) self.namegenerator = generator or CorvusNames end

function Pipeline:seed()
    if self.Seed and self.Seed > 0 then
        math.randomseed(self.Seed)
    else
        local t = os.time()
        local extra = tonumber(string.sub(tostring({}), 8), 16) or 0
        math.randomseed((t + extra) % 2147483647)
    end
end

function Pipeline:renameVariables(ast)
    local generator = self.namegenerator
    if generator.prepare then generator.prepare(ast) end
    ast.globalScope:renameVariables({
        Keywords = self.conventions.Keywords,
        generateName = generator.generateName,
        prefix = self.VarNamePrefix,
    })
end


function Pipeline:wrapWithVM(source)
    assert(type(source) == "string" and #source > 0, "Corvus VM received empty source")
    local count = math.max(1, math.min(5, self.VMCount or 1))

    -- Keep VM depth from multiplying the payload size. Older versions wrapped
    -- an already-expanded byte table inside another byte table for every VM
    -- layer, which made large scripts grow exponentially. We instead apply
    -- all VM keys to the payload once and decode them in reverse order.
    local keys = {}
    for i = 1, count do
        keys[i] = math.random(17, 241)
    end

    -- Hex keeps the payload compact enough for very large scripts and avoids
    -- generating one Lua numeric AST node per source byte.
    local hex = {}
    for i = 1, #source do
        local b = source:byte(i)
        for layer = 1, count do
            b = (b + keys[layer] + (i % 17)) % 256
        end
        hex[#hex + 1] = string.format("%02x", b)
    end

    local keyList = {}
    for i = 1, count do
        keyList[i] = tostring(keys[i])
    end

    return string.format([[
local __corvus_vm_payload=%q
local __corvus_vm_keys={%s}
local __corvus_vm_decode=function(payload,keys)
    local out={}
    local outIndex=1
    local sourceIndex=1
    for i=1,#payload,2 do
        local b=tonumber(payload:sub(i,i+1),16)
        if not b then error("Corvus VM payload is invalid") end
        for layer=#keys,1,-1 do
            b=(b-keys[layer]-((sourceIndex)%%17))%%256
        end
        out[outIndex]=string.char(b)
        outIndex=outIndex+1
        sourceIndex=sourceIndex+1
    end
    return table.concat(out)
end
local __corvus_vm_load=loadstring or load
local __corvus_vm_source=__corvus_vm_decode(__corvus_vm_payload,__corvus_vm_keys)
local __corvus_vm_chunk,__corvus_vm_error=__corvus_vm_load(__corvus_vm_source,"@corvus_vm","t")
if not __corvus_vm_chunk then error(__corvus_vm_error) end
return __corvus_vm_chunk()
]], table.concat(hex), table.concat(keyList, ","))
end

function Pipeline:apply(code, filename)
    assert(type(code) == "string", "Corvus expects source code as a string")
    local sourceLen = #code
    -- Do not impose a small hard engine limit. The parser/worker is responsible
    -- for handling the available memory; rejecting a valid script at 2 MiB was
    -- the direct cause of large-input failures.
    self:seed()
    logger:info("Corvus: parsing source")
    local ast = self.parser:parse(code)

    for _, step in ipairs(self.steps) do
        logger:info("Corvus: applying " .. tostring(step.Name))
        local result = step:apply(ast, self)
        if type(result) == "table" then ast = result end
    end

    self:renameVariables(ast)
    local output = self.unparser:unparse(ast)

    if self.UseVM then
        output = self:wrapWithVM(output)
    end

    output = "--[[corvus\\//ofuscador]]\n" .. output

    if self.ValidateOutput then
        local ok, err = pcall(function() self.parser:parse(output) end)
        if not ok then
            error("Corvus output validation failed: " .. tostring(err))
        end
    end
    assert(type(output) == "string" and #output > 0, "Corvus produced an empty output")

    logger:info(string.format("Corvus: generated %.2f%% of source size", sourceLen > 0 and (#output / sourceLen) * 100 or 0))
    return output
end

return Pipeline
