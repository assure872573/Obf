_G.newproxy = _G.newproxy or function(arg)
    if arg then return setmetatable({}, {}) end
    return {}
end

local Pipeline = require("corvus.pipeline")
local Presets = require("presets")
local colors = require("colors")
local Logger = require("logger")
local Config = require("config")
local util = require("corvus.frontend.util")

return {
    Pipeline = Pipeline,
    Presets = Presets,
    colors = colors,
    Logger = Logger,
    Config = util.readonly(Config),
}
