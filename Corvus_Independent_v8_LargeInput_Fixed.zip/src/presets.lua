return {
    Medium = {
        LuaVersion = "LuaU",
        VarNamePrefix = "",
        PrettyPrint = false,
        Seed = 0,
        ValidateOutput = true,
        UseVM = true,
        VMCount = 1,
        NameGenerator = "Corvus",
        Steps = {
            {Name = "LiteralMorph", Settings = {StringThreshold = 1, NumberThreshold = 0.80}},
            {Name = "ExpressionMorph", Settings = {Threshold = 0.55, Enabled = true}},
            {Name = "StructureMorph", Settings = {Threshold = 0.65}},
        },
    },
}
