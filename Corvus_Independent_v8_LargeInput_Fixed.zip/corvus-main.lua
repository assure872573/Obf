local function script_path()
    local str = debug.getinfo(2, "S").source:sub(2)
    return str:match("(.*[/%\\])") or ""
end
local oldPkgPath = package.path
package.path = script_path() .. "?.lua;" .. package.path
local Corvus = require("src.corvus")
package.path = oldPkgPath
return Corvus
