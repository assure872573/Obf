-- Corvus runtime safety regressions
local cases = {
    [[local string = { char = function() error("shadowed string.char") end }
local msg = "hello"
return msg]],
    [[local function f(x) return x + 1 end
local a = 10
return f(a)]],
    [[local msg = "\0\1\2\255"
return msg]],
}

for i, code in ipairs(cases) do
    assert(type(code) == "string" and #code > 0, "invalid regression case " .. i)
end

return true
