local root = "src/corvus"
local forbidden = {"require(%\"prometheus", "require('prometheus", "prometheus.pipeline", "prometheus.parser", "prometheus.ast", "prometheus.unparser", "prometheus.scope", "prometheus.compiler"}
local handle = io.popen("grep -RIn -E 'require\\([\\\"\\x27]prometheus|prometheus\\.(pipeline|parser|ast|unparser|scope|compiler)' " .. root .. " 2>/dev/null")
local output = handle:read("*a")
handle:close()
if output ~= "" then
    io.stderr:write("CORVUS INDEPENDENCE CHECK: FAIL\n" .. output)
    os.exit(1)
end
print("CORVUS INDEPENDENCE CHECK: PASS")
print("Active Corvus runtime has no direct Prometheus module dependencies.")
