# Corvus Web

The Corvus web playground runs the Corvus engine in a dedicated Web Worker through Wasmoon. The active browser bundle loads Lua sources from `src/` via the Vite `virtual:corvus-lua` plugin.

The application is Luau-first: the UI exposes only the supported `LuaU` runtime.
