import { describe, expect, it } from "vitest"

import { luaPathToModuleName } from "./corvusLuaPlugin"

describe("luaPathToModuleName", () => {
  it.each([
    ["src/corvus.lua", "corvus"],
    ["src/presets.lua", "presets"],
    ["src/corvus/pipeline.lua", "corvus.pipeline"],
    ["src/corvus/compiler/expressions/string.lua", "corvus.compiler.expressions.string"],
  ])("maps %s to %s", (filePath, moduleName) => {
    expect(luaPathToModuleName(filePath)).toBe(moduleName)
  })
})
