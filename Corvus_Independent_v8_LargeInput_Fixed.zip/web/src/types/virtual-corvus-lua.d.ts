declare module "virtual:corvus-lua" {
  const sources: Record<string, string>
  export default sources
}
