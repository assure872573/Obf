import { describe, expect, it } from "vitest"

import { type PresetName } from "@/lib/corvusTypes"
import { runCorvus } from "./corvusRunner"

function options(preset: PresetName) {
  return {
    source: 'print("Hello, World!")',
    filename: "hello.lua",
    preset,
    luaVersion: "LuaU" as const,
    prettyPrint: false,
    seed: 12345,
  }
}

describe("runCorvus", () => {
  it("obfuscates a simple script with Medium", async () => {
    const result = await runCorvus(options("Medium"))

    if (!result.ok) {
      throw new Error(result.error)
    }
    expect(result.ok).toBe(true)
    if (result.ok) {
      expect(result.output.length).toBeGreaterThan(0)
      expect(result.logs.length).toBeGreaterThan(0)
    }
  }, 30000)

})
