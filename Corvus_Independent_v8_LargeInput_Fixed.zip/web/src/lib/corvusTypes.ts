export const PRESETS = ["Medium"] as const
export const LUA_VERSIONS = ["LuaU"] as const

export type PresetName = (typeof PRESETS)[number]
export type LuaVersion = (typeof LUA_VERSIONS)[number]
export type LogLevel = "info" | "warn" | "error" | "debug"

export interface CorvusOptions {
  source: string
  filename: string
  preset: PresetName
  luaVersion: LuaVersion
  prettyPrint: boolean
  seed: number
  useVM?: boolean
  vmCount?: number
}

export interface CorvusLog {
  level: LogLevel
  message: string
}

export interface CorvusSuccess {
  ok: true
  output: string
  logs: CorvusLog[]
}

export interface CorvusFailure {
  ok: false
  error: string
  logs: CorvusLog[]
}

export type CorvusResult = CorvusSuccess | CorvusFailure

export type WorkerRequest =
  | { id: number; action: "obfuscate"; options: CorvusOptions }
  | { id: number; action: "runScript"; source: string; filename: string }

export type WorkerResponse =
  | { id: number; type: "result"; result: CorvusResult }
  | { id: number; type: "log"; log: CorvusLog }
